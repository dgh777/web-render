module.exports = {
  // Token do bot (necessário para dar cargo e enviar log)
  token: process.env.BOT_TOKEN || "",

  // Já configurado — não precisa mudar
  id: "1523114141517348976",
  secret: process.env.BOT_CLIENT_SECRET || "",
  verifyRole: "1522636913645981787",
  guildId: process.env.BOT_GUILD_ID || "1480249438034202666",
  logChannel: process.env.BOT_LOG_CHANNEL || "1523358001476534282",

  // URL de redirect — será a URL do Render (ex: https://meuapp.onrender.com/)
  redirectUri: process.env.BOT_REDIRECT_URI || "",

  port: parseInt(process.env.PORT || "3000"),
}
